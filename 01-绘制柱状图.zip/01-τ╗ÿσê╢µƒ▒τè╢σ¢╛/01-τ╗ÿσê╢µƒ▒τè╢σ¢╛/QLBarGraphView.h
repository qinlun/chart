//
//  QLBarGraphView.h
//  01-绘制柱状图
//
//  Created by qinlun on 2017/8/21.
//  Copyright © 2017年 qinlun. All rights reserved.
//  柱状图

#import <UIKit/UIKit.h>

@interface QLBarGraphView : UIView

@property (nonatomic, strong) NSArray *leftYAxis; //左边的Y轴数据(从大到小排列)
@property (nonatomic, strong) NSArray *bottomXAxis; //底部的x轴数据 ( <= upperLimit 且upperLimit必须为bottomXAxis的倍数)
@property (nonatomic, assign) CGFloat upperLimit; //柱状个数上限
@property (nonatomic, strong) NSArray *dataSources; //柱状数据( <= upperLimit)

@end
