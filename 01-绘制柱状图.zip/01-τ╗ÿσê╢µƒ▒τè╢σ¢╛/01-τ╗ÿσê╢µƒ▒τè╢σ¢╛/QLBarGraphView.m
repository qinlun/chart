//
//  QLBarGraphView.m
//  01-绘制柱状图
//
//  Created by qinlun on 2017/8/21.
//  Copyright © 2017年 qinlun. All rights reserved.
//  柱状图

#import "QLBarGraphView.h"


#define Kppading 30
#define kmargin 5 //柱状图起始位置距离y轴距离

//边线颜色
#define CPColor16(s)  [UIColor colorWithRed:(((s & 0xFF0000) >> 16))/255.0 green:(((s &0xFF00) >>8))/255.0 blue:((s &0xFF))/255.0 alpha:1.0]

#define CPGrayColor CPColor16(0x999999) //灰色(轴线颜色)
#define CPDashColor CPColor16(0xD2D2D2) //虚线颜色
#define CPBarColor CPColor16(0xffff44) //柱状的颜色

@interface QLBarGraphView ()

//绘图区域的起点和大小
@property (nonatomic,assign) CGFloat originX;
@property (nonatomic,assign) CGFloat originY;
@property (nonatomic,assign) CGFloat bgWidth;
@property (nonatomic,assign) CGFloat bgHeight;

@property (nonatomic, assign)CGFloat YAxisDashNumber;//虚线条数
@property (nonatomic, assign)CGFloat dashSection;//y轴最大最小值之间的区间
@property (nonatomic, assign)CGFloat barNumber;//柱状图个数
@property (nonatomic, assign)CGFloat barWidth;//柱状图的宽度
@property (nonatomic, assign)CGFloat barpadding;//柱状图的间距（为方便计算 barWidth = barpadding）

@end

@implementation QLBarGraphView


- (void)drawRect:(CGRect)rect {

    self.originX = rect.origin.x+Kppading;
    self.originY = rect.origin.y+Kppading;
    self.bgWidth = rect.size.width - 2*Kppading;
    self.bgHeight = rect.size.height - 2*Kppading;
    
    NSLog(@"--%lf--%lf--%lf--%lf", self.originX, self.originY, self.bgWidth, self.bgHeight);
    
    //左边y轴上虚线条数 = y轴数据个数 - 1
    if (self.leftYAxis == nil || self.leftYAxis.count == 0) {
        
        return;
        
    }else{
        self.YAxisDashNumber = self.leftYAxis.count - 1;
        self.dashSection = fabsf([[self.leftYAxis firstObject] floatValue] - [[self.leftYAxis lastObject] floatValue]);
    }

    
    
    
    //柱状图的个数 = 数据源的个数
    if (self.dataSources == nil || self.dataSources.count == 0) {
        
        return ;
        
    }else{
        self.barNumber = self.dataSources.count;
    }
    
    //柱状图的宽度
    self.barWidth = (self.bgWidth - kmargin * 2)/(self.upperLimit * 2 - 1);
    //柱状图的间距（为方便计算 barWidth = barpadding）
    self.barpadding = self.barWidth;
    
    NSLog(@"--%lf--%lf", self.barWidth, self.barpadding);
    
    //1.绘制左边y轴线
    [self createLeftY];
    
    //2.绘制右边y轴线
    [self createRightY];
    
    //3.绘制底部的X轴线
    [self createBottomX];
    
    //4.绘制水平虚线(4段)
    CGFloat dashStyle[] = {8.0f, 4.0f};
    [self createhorizontalDash:dashStyle count:2 phase:0.0];
    
    //5.绘制柱状图
    [self createBar];
}



- (void)createLeftY{
    
    UIBezierPath *path = [UIBezierPath bezierPath];
    
    [path moveToPoint:CGPointMake(self.originX, self.originY)];
    [path addLineToPoint:CGPointMake(self.originX, (self.bgHeight+Kppading))];
    
    path.lineWidth = 1.0f;
    [CPGrayColor set];
    path.lineJoinStyle = kCGLineJoinRound;
    [path stroke];
    
}




- (void)createRightY{

    UIBezierPath *path = [UIBezierPath bezierPath];
    
    [path moveToPoint:CGPointMake((self.originX+self.bgWidth), self.originY)];
    [path addLineToPoint:CGPointMake((self.originX+self.bgWidth), (self.bgHeight+Kppading))];
    
    path.lineWidth = 1.0f;
    [CPGrayColor set];
    path.lineJoinStyle = kCGLineJoinRound;
    [path stroke];
}




- (void)createBottomX{

    UIBezierPath *path = [UIBezierPath bezierPath];
    
    [path moveToPoint:CGPointMake(self.originX, (self.bgHeight+Kppading))];
    [path addLineToPoint:CGPointMake((self.originX+self.bgWidth), (self.bgHeight+Kppading))];
    
    path.lineWidth = 1.0f;
    [CPGrayColor set];
    path.lineJoinStyle = kCGLineJoinRound;
    [path stroke];
}



- (void)createhorizontalDash:(nullable const CGFloat *)pattern count:(NSInteger)count phase:(CGFloat)phase{
    
    //通过富文本属性设置文字
    NSMutableParagraphStyle *ps = [[NSMutableParagraphStyle alloc] init];
    [ps setAlignment:NSTextAlignmentCenter];
    NSDictionary *textAttr = @{NSFontAttributeName: [UIFont systemFontOfSize:10],
                               NSForegroundColorAttributeName:CPGrayColor,
                               NSParagraphStyleAttributeName:ps
                               };
    
    UIBezierPath *path = [UIBezierPath bezierPath];
    
    CGFloat padding = self.bgHeight/self.YAxisDashNumber;
    for (int i = 0; i < self.YAxisDashNumber; i++) {
        
        //绘制y轴线上的虚线
        [path moveToPoint:CGPointMake(self.originX, self.originY+padding*i)];
        [path addLineToPoint:CGPointMake(self.originX+self.bgWidth, self.originY+padding*i)];
        [path setLineDash:pattern count:count phase:0.0];
        [CPDashColor set];
        [path stroke];
        
        //绘制y轴的文字
        NSString *text = [NSString stringWithFormat:@"%@",self.leftYAxis [i]];
        [text drawInRect:CGRectMake(0, self.originY+padding*i - 10, 30, 20) withAttributes:textAttr];
    }
    
    //绘制0轴上的数字
    NSString *minStr = [NSString stringWithFormat:@"%@",[self.leftYAxis lastObject]];
    [minStr drawInRect:CGRectMake(0, self.originY+self.bgHeight -20*0.5, 30, 20) withAttributes:textAttr];
    
}



- (void)createBar{

    for (int i = 0; i < self.barNumber; i++) {
        
        CGFloat x = Kppading + kmargin + self.barpadding * i + self.barWidth * i;
        CGFloat width = self.barWidth;
        CGFloat height = (([((NSNumber *)self.dataSources[i]) floatValue] - [[self.leftYAxis lastObject] floatValue])/self.dashSection) * self.bgHeight;
        CGFloat y = Kppading+ (self.bgHeight - height) - 0.5;
        UIBezierPath *path = [UIBezierPath bezierPathWithRect:CGRectMake(x, y, width, height)];
        //stroke方法填充内部
        [CPBarColor set];
        [path fill];
        
        
    }
    
    
    //绘制X轴的文字
    NSMutableParagraphStyle *ps = [[NSMutableParagraphStyle alloc] init];
    [ps setAlignment:NSTextAlignmentCenter];
    NSDictionary *textAttr = @{NSFontAttributeName: [UIFont systemFontOfSize:10],
                               NSForegroundColorAttributeName:CPGrayColor,
                               NSParagraphStyleAttributeName:ps,
                               };
    for (int i = 0; i < self.bottomXAxis.count; i++) {
    
        CGFloat x = Kppading + kmargin + self.barpadding * i + self.barWidth * i;
        
        NSString *text = [NSString stringWithFormat:@"%@",self.bottomXAxis[i]];
        [text drawInRect:CGRectMake(x, self.bgHeight+Kppading, self.barWidth, Kppading) withAttributes:textAttr];
    }
}



#pragma mark -- <重写这几个属性的set方法，当值改变的时候重绘>
- (void)setLeftYAxis:(NSArray *)leftYAxis{
    
    _leftYAxis = leftYAxis;
    
    [self setNeedsDisplay];
}

- (void)setBottomXAxis:(NSArray *)bottomXAxis{
    
    _bottomXAxis = bottomXAxis;
    
    [self setNeedsDisplay];
}


- (void)setUpperLimit:(CGFloat)upperLimit{
    
    _upperLimit = upperLimit;
    
    [self setNeedsDisplay];
}

- (void)setDataSources:(NSArray *)dataSources{
    
    _dataSources = dataSources;
    
    [self setNeedsDisplay];
}


@end
