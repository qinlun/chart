//
//  ViewController.m
//  01-绘制柱状图
//
//  Created by qinlun on 2017/8/21.
//  Copyright © 2017年 qinlun. All rights reserved.
//

#import "ViewController.h"
#import "QLBarGraphView.h"

@interface ViewController ()

@property (nonatomic, strong)QLBarGraphView *barView;

@end

@implementation ViewController

#pragma mark -- <懒加载>
- (QLBarGraphView *)barView{
    
    if (!_barView) {
        _barView = [[QLBarGraphView alloc]initWithFrame:CGRectMake(0, 0, 300, 200)];
        _barView.backgroundColor = [UIColor whiteColor];
    }
    return _barView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    self.barView.leftYAxis = @[@4000, @3000, @2000 , @1000, @0];
    self.barView.bottomXAxis = @[@"一", @"二", @"三", @"四", @"五", @"六", @"七"];
    self.barView.upperLimit = 12;
    self.barView.dataSources = @[@1500, @1000, @2000, @2500, @3500, @4000];
    
    self.barView.backgroundColor = [UIColor whiteColor];
    self.barView.center = self.view.center;
    [self.view addSubview:self.barView];
}



#pragma mark -- <点击屏幕刷新>
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    self.barView.leftYAxis = @[@4000, @3000, @2000 , @1000, @0];
    self.barView.bottomXAxis = @[@"一", @"二", @"三", @"四", @"五", @"六", @"七", @"八", @"九", @"十"];
    self.barView.upperLimit = 10;
    self.barView.dataSources = @[@1500, @1000, @2000, @2500, @3500, @4000];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
