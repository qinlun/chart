//
//  QLLineGraphView.h
//  02-绘制折线图
//
//  Created by qinlun on 2017/8/21.
//  Copyright © 2017年 qinlun. All rights reserved.
//  折线图

#import <UIKit/UIKit.h>

@interface QLLineGraphView : UIView

@property (nonatomic, strong) NSArray *leftYAxis; //左边的Y轴数据(从大到小排列)
@property (nonatomic, strong) NSArray *bottomXAxis; //底部的x轴数据 ( <= upperLimit 且upperLimit必须为bottomXAxis的倍数)
@property (nonatomic, assign) CGFloat upperLimit; //折线点个数上限
@property (nonatomic, strong) NSArray *dataSources; //图表数据( <= upperLimit)


@end
