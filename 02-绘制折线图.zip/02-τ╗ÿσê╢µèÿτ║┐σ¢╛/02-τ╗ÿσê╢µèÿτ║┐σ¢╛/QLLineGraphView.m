//
//  QLLineGraphView.m
//  02-绘制折线图
//
//  Created by qinlun on 2017/8/21.
//  Copyright © 2017年 qinlun. All rights reserved.
//  折线图

#import "QLLineGraphView.h"


#define Kppading 30

//颜色
#define CPColor(r,g,b,a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]
#define CPColor16(s)  [UIColor colorWithRed:(((s & 0xFF0000) >> 16))/255.0 green:(((s &0xFF00) >>8))/255.0 blue:((s &0xFF))/255.0 alpha:1.0]

#define CPGrayColor CPColor16(0x999999) //灰色(轴线颜色)
#define CPDashColor CPColor16(0xD2D2D2) //虚线颜色
#define CPLineGraphColor CPColor16(0xff0000) //折线的颜色

@interface QLLineGraphView ()

//绘图区域的起点和大小
@property (nonatomic,assign) CGFloat originX;
@property (nonatomic,assign) CGFloat originY;
@property (nonatomic,assign) CGFloat bgWidth;
@property (nonatomic,assign) CGFloat bgHeight;

@property (nonatomic, assign)CGFloat YAxisDashNumber;//虚线条数
@property (nonatomic, assign)CGFloat dashSection;//y轴最大最小值之间的区间

@property (nonatomic, assign)CGFloat dotNumber;//需要绘制的点个数
@property (nonatomic, assign)CGFloat dotpadding;//点与点之间的间距


@end

@implementation QLLineGraphView

- (void)drawRect:(CGRect)rect {
    
    self.originX = rect.origin.x+Kppading;
    self.originY = rect.origin.y+Kppading;
    self.bgWidth = rect.size.width - 2*Kppading;
    self.bgHeight = rect.size.height - 2*Kppading;
    
    //NSLog(@"--%lf--%lf--%lf--%lf", self.originX, self.originY, self.bgWidth, self.bgHeight);
    
    //左边y轴上虚线条数 = y轴数据个数 - 1
    if (self.leftYAxis == nil || self.leftYAxis.count == 0) {
        
        return;

    }else{
        self.YAxisDashNumber = self.leftYAxis.count - 1;
        self.dashSection = fabsf([[self.leftYAxis firstObject] floatValue] - [[self.leftYAxis lastObject] floatValue]);
    }
    
    //点的个数 = 数据源的个数
    if (self.dataSources == nil || self.dataSources.count == 0) {
    
        return ;
        
    }else{
        self.dotNumber = self.dataSources.count;
    }
   
    //点与点之间的间距 = 总宽度 ／ （点上线个数 - 1）
    self.dotpadding = self.bgWidth/(self.upperLimit-1);
    
    
    
    //1.绘制左边y轴线
    [self createLeftY];
    
    //2.绘制右边y轴线
    [self createRightY];
    
    //3.绘制底部的X轴线
    [self createBottomX];
    
    //4.绘制左边水平虚线(4段)及文字
    CGFloat dashStyle[] = {8.0f, 4.0f};
    [self createhorizontalDash:dashStyle count:2 phase:0.0];
    
    //5.绘制折线图
    [self createLineGraph];
    
    //6.在具体的点那里绘制大的原点
    [self createPoint];
}



- (void)createLeftY{
    
    UIBezierPath *path = [UIBezierPath bezierPath];
    
    [path moveToPoint:CGPointMake(self.originX, self.originY)];
    [path addLineToPoint:CGPointMake(self.originX, (self.bgHeight+Kppading))];
    
    path.lineWidth = 1.0f;
    [CPGrayColor set];
    path.lineJoinStyle = kCGLineJoinRound;
    [path stroke];
    
}




- (void)createRightY{
    
    UIBezierPath *path = [UIBezierPath bezierPath];
    
    [path moveToPoint:CGPointMake((self.originX+self.bgWidth), self.originY)];
    [path addLineToPoint:CGPointMake((self.originX+self.bgWidth), (self.bgHeight+Kppading))];
    
    path.lineWidth = 1.0f;
    [CPGrayColor set];
    path.lineJoinStyle = kCGLineJoinRound;
    [path stroke];
}




- (void)createBottomX{
    
    UIBezierPath *path = [UIBezierPath bezierPath];
    
    [path moveToPoint:CGPointMake(self.originX, (self.bgHeight+Kppading))];
    [path addLineToPoint:CGPointMake((self.originX+self.bgWidth), (self.bgHeight+Kppading))];
    
    path.lineWidth = 1.0f;
    [CPGrayColor set];
    path.lineJoinStyle = kCGLineJoinRound;
    [path stroke];
}



- (void)createhorizontalDash:(nullable const CGFloat *)pattern count:(NSInteger)count phase:(CGFloat)phase{
    
    //通过富文本属性设置文字
    NSMutableParagraphStyle *ps = [[NSMutableParagraphStyle alloc] init];
    [ps setAlignment:NSTextAlignmentCenter];
    NSDictionary *textAttr = @{NSFontAttributeName: [UIFont systemFontOfSize:10],
                               NSForegroundColorAttributeName:CPGrayColor,
                               NSParagraphStyleAttributeName:ps
                               };
    
    UIBezierPath *path = [UIBezierPath bezierPath];
    
    CGFloat padding = self.bgHeight/self.YAxisDashNumber;
    for (int i = 0; i < self.YAxisDashNumber; i++) {
        
        //绘制y轴线上的虚线
        [path moveToPoint:CGPointMake(self.originX, self.originY+padding*i)];
        [path addLineToPoint:CGPointMake(self.originX+self.bgWidth, self.originY+padding*i)];
        [path setLineDash:pattern count:count phase:0.0];
        [CPDashColor set];
        [path stroke];
        
        //绘制y轴的文字
        NSString *text = [NSString stringWithFormat:@"%@",self.leftYAxis [i]];
        [text drawInRect:CGRectMake(0, self.originY+padding*i - 10, 30, 20) withAttributes:textAttr];
    }
    
    //绘制0轴上的数字
    NSString *minStr = [NSString stringWithFormat:@"%@",[self.leftYAxis lastObject]];
    [minStr drawInRect:CGRectMake(0, self.originY+self.bgHeight -20*0.5, 30, 20) withAttributes:textAttr];
    
}



- (void)createLineGraph{
    
    UIBezierPath *path = [UIBezierPath bezierPath];
    //起点
    CGFloat height = (([((NSNumber *)self.dataSources[0]) floatValue] - [[self.leftYAxis lastObject] floatValue])/self.dashSection) * self.bgHeight;
    CGFloat y = Kppading+ (self.bgHeight - height);
    [path moveToPoint:CGPointMake(Kppading, y)];
    
    CGFloat dashStyle[] = {1.0f, 1.0f};
    for (int i = 0; i < self.dotNumber; i++) {
        
        CGFloat x = Kppading + self.dotpadding * i;
        
        CGFloat height = (([((NSNumber *)self.dataSources[i]) floatValue] - [[self.leftYAxis lastObject] floatValue])/self.dashSection) * self.bgHeight;
        CGFloat y = Kppading+ (self.bgHeight - height);
        
        [path addLineToPoint:CGPointMake(x, y)];
        [path setLineDash:dashStyle count:2 phase:0.0];
        
        [CPLineGraphColor set];
        [path stroke];
        
    }
    
    
    //围起来 填充内部颜色
    [CPGrayColor set];
    [path addLineToPoint:CGPointMake((Kppading + self.dotpadding * (self.dotNumber- 1)), (self.bgHeight+Kppading))];
    [path addLineToPoint:CGPointMake(self.originX, (self.bgHeight+Kppading))];
    [path addLineToPoint:CGPointMake(Kppading, y)];
    [CPColor(179, 237, 246, 0.2) setFill];
    [path fill];
    
    
    //绘制X轴的文字
    NSMutableParagraphStyle *ps = [[NSMutableParagraphStyle alloc] init];
    [ps setAlignment:NSTextAlignmentCenter];
    NSDictionary *textAttr = @{NSFontAttributeName: [UIFont systemFontOfSize:10],
                               NSForegroundColorAttributeName:CPGrayColor,
                               NSParagraphStyleAttributeName:ps
                               };

    int ratio = self.upperLimit/self.bottomXAxis.count;
    for (int i = 1; i < self.bottomXAxis.count+1; i++) {
        
        CGFloat x = Kppading+ (ratio * i * self.dotpadding) - self.dotpadding ;
        
        //绘制y轴的文字
        NSString *text = [NSString stringWithFormat:@"%@",self.bottomXAxis[i-1]];
        [text drawInRect:CGRectMake(x-self.dotpadding*0.5, self.bgHeight+Kppading, self.dotpadding, Kppading) withAttributes:textAttr];
    }
}



- (void)createPoint{

    CGFloat pointW = 5;
    
    for (int i = 0; i < self.dotNumber; i++) {
        
        CGFloat x = Kppading + self.dotpadding * i;
        
        CGFloat height = (([((NSNumber *)self.dataSources[i]) floatValue] - [[self.leftYAxis lastObject] floatValue])/self.dashSection) * self.bgHeight;
        CGFloat y = Kppading+ (self.bgHeight - height);
        
        UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(x - pointW*0.5, y - pointW*0.5, pointW, pointW) cornerRadius:pointW*0.5];
        [CPLineGraphColor set];
        [path fill];
    }
}


#pragma mark -- <重写这几个属性的set方法，当值改变的时候重绘>
- (void)setLeftYAxis:(NSArray *)leftYAxis{

    _leftYAxis = leftYAxis;

    [self setNeedsDisplay];
}

- (void)setBottomXAxis:(NSArray *)bottomXAxis{

    _bottomXAxis = bottomXAxis;
    
    [self setNeedsDisplay];
}


- (void)setUpperLimit:(CGFloat)upperLimit{

    _upperLimit = upperLimit;
    
    [self setNeedsDisplay];
}

- (void)setDataSources:(NSArray *)dataSources{

    _dataSources = dataSources;
    
    [self setNeedsDisplay];
}


@end
