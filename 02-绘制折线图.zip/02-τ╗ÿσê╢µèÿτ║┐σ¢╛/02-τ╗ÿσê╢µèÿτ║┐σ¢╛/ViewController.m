//
//  ViewController.m
//  02-绘制折线图
//
//  Created by qinlun on 2017/8/21.
//  Copyright © 2017年 qinlun. All rights reserved.
//  

#import "ViewController.h"
#import "QLLineGraphView.h"


@interface ViewController ()

@property (nonatomic, strong)QLLineGraphView *lineGraph;

@end

@implementation ViewController

#pragma mark -- <懒加载>
- (QLLineGraphView *)lineGraph{

    if (!_lineGraph) {
        _lineGraph = [[QLLineGraphView alloc]initWithFrame:CGRectMake(0, 0, 300, 200)];
        _lineGraph.backgroundColor = [UIColor whiteColor];
    }
    return _lineGraph;
}



- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    self.lineGraph.leftYAxis = @[@400, @300, @200, @100 ,@0];
    
    self.lineGraph.bottomXAxis = @[@"一",@"二", @"三" ,@"四", @"五", @"六", @"七", @"八",@"九" ,@"十",@"十一",@"十二"];
    //lineGraph.bottomXAxis = @[@"二",  @"四",   @"六", @"八", @"十", @"十二"];
    //lineGraph.bottomXAxis = @[@"六", @"十二"];
    self.lineGraph.upperLimit = 12;
    self.lineGraph.dataSources = @[@50, @100, @88, @320, @60, @210,@50, @100, @88, @320, @60, @210];
    self.lineGraph.center = self.view.center;
    [self.view addSubview:self.lineGraph];
}

#pragma mark -- <点击屏幕刷新>
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    self.lineGraph.leftYAxis = @[@300, @200, @100 ,@0];
    
    self.lineGraph.bottomXAxis = @[@"二",  @"四",  @"六", @"八", @"十", @"十二"];
    
    self.lineGraph.upperLimit = 6;
    
    self.lineGraph.dataSources = @[@50, @88, @210,@50, @60, @210];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
